5. HW Collections Generics Interfaces
