package com.example.a5hwcollectionsgenericsinterfaces

enum class Types {
    STANDARD_TYPE,
    RE_POST_TYPE,
    EVENT_TYPE,
    POST_WITH_VIDEO_TYPE,
    PROMOTION_TYPE
}